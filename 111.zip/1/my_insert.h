
int insert(const char* psw ,const char * usrname);
