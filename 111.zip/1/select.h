int myselect(const char * password,const char* usrname);
